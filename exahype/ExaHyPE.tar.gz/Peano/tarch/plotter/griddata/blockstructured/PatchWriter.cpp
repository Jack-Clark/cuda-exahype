#include "tarch/plotter/griddata/blockstructured/PatchWriter.h"


tarch::plotter::griddata::blockstructured::PatchWriter::~PatchWriter() {
}
