#include "tarch/plotter/globaldata/TXTTableWriter.h"

